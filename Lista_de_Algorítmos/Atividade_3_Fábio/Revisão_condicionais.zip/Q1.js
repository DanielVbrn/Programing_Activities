import {input} from "../../io_utils.js"
//Numero negativo ou postivo.
function main(){
const num = Number(input("Insira um número: "))
if(num>0){
    console.log('É positivo')
}else{
    console.log('É negativo')

}




}
main()