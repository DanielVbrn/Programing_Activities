import {} from "../../io_utils.js"

function main(){
     
    for(let num = 1 ; num <= 10 ; num++){
        const n1 = 1 * num
        const n2 = 2 * num
        const n3 = 3 * num
        const n4 = 4 * num
        const n5 = 5 * num
        const n6 = 6 * num
        const n7 = 7 * num
        const n8 = 8 * num
        const n9 = 9 * num
        const n10 = 10 * num

        console.log(`${n1}    ${n2}    ${n3}    ${n4}    ${n5}    ${n6}    ${n7}    ${n8}    ${n9}    ${n10}`)
    }


}
main()